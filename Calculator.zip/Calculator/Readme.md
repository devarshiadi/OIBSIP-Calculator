<p align="center">
<img src="https://raw.githubusercontent.com/trinib/trinib/main/.images/marquee.svg">